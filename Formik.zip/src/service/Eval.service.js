
import axios from "axios";
// Login
export const login = (email, password) => {
  const config = {
    method: 'post',
    url: 'https://api.fvth.freshvoice.app/users/login',
    headers: {
      'Content-Type': 'application/json',
    },
    data: {
      "email": email,
      "password": password
    },
  };

  return axios(config);

};



export const getAllProb = (token) => {
    const config = {
      method: 'get',
       url: 'https://api.fvth.freshvoice.app/panel-board/problem-statements',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      }
    };
  
    return axios(config);
  
  };

  

  export const getAllTeam = (token) => {
    const config = {
      method: 'get',
       url: 'https://api.fvth.freshvoice.app/panel-board/teams',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      }
    };
  
    return axios(config);
  
  };
