import React from 'react';
import { Switch, Route, Router } from 'react-router-dom';
import { StylesProvider, createGenerateClassName } from '@material-ui/core/styles';


// import GenChkRpt from './components/GenChkRpt';
// import Accord from './components/accordion';
// import Tech from './components/eval';
import Validation from './components/validation';

const generateClassName = createGenerateClassName({
    productionPrefix: 'Tech',
});

export default ({ history }) => {
    return <div>
        <StylesProvider generateClassName={generateClassName}>
            <Router history={history}>
                <Switch>
                    <Route path="/" component={Validation} />
                    
                </Switch>
            </Router>
        </StylesProvider>
    </div>
};