import React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
// import './valid.css';
import { Box } from "@mui/system";
import { useFormik } from "formik";
import * as Yup from 'yup';
//date picker
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
//dropdown
import Autocomplete from '@mui/material/Autocomplete';
import { AgAbstractField } from "ag-grid-community";
import './ag.css';


function Validation() {

 {/*  const validate = (values) => {
    const errors = {};
    
    if (!values.name) {
      errors.name = "Field is required";
    }
    else if (!/^[ a-zA-Z\-\’]+$/.test(values.name)) {
      errors.name = "Invalid name";
    }


    if (!values.email) {
      errors.email = 'Field is required';
    }
    else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
      errors.email = 'Invalid email address';
    }


    if (!values.num) {
      errors.num = "Field is required";
    }
    else if (!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(values.num)) {
      errors.num = "Invalid Mobile number";
    }

    if (!values.pass) {
      errors.pass = "Field is required";
    }
    else if (!/^(?=.[a-z])(?=.[A-Z])(?=.[0-9])(?=.[!@#\$%\^&\*])(?=.{8,})/.test(values.pass)) {
      errors.pass = "Please give the strong password";
    }
    if (!values.dob) {
      errors.dob = "Field is required";
    }
    else if (
      !/^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/.test(values.dob)) {
      errors.dob = "choose valid dob";
    }

    if (!values.skills) {
      errors.skills = "Field is required";
    }
    else if ((values.Gender = "")) {
      errors.Gender = "Field is required";
    }
    return errors;
  };*/}




  const [value1, setValue1] = React.useState(null);
//   const [value, setValue] = React.useState(null);


const FormSchema = Yup.object().shape({
    name: Yup.string().matches(/^[aA-zZ\s]+$/,"Only alphabets are allowed for this field ").min(3, "It's too short").required("Field is required"),
  
      email: Yup.string().email().required("Field is required"),
  
      num: Yup.string()
      .required("Field is required")
      .matches(
        "^[0-9]{10}$",
        "Invalid phone number"
      ),

      pass: Yup.string()
      .required("Field is required")
      .min(8, "Password is too short - should be 8 chars minimum"),


      dob: Yup.string().required("Field is required"),

      skills: Yup.string().required("Field is required"),

  
   
  
   


  });
 


  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: false,
    validationSchema: FormSchema,
    onSubmit: (newvalue) => {
      console.log(newvalue);
      alert("Submit Successfully");
    },
    initialValues: {
      name: '',
      email: '',
      num: '',
      pass: '',
      dob: '',
      skills: '',
     
  }

  })

  

// const onSubmit = (values) => {
//     console.log(values)
//     // console.log(props)
//     setTimeout(() => {

//         props.resetForm()
//         props.setSubmitting(false)
//     }, 2000)
// }



//   const formik = useFormik({
//     initialValues: {
//       name: "",
//       email: "",
//       num: "",
//       pass: "",
//       dob: "",
//       skills: "",
//     },
//     validate,
//     onSubmit: (values) => {
//       alert(`Save Successfully!....`);
//     },
//   });


const {  // these functiions essential for formik yup
    handleChange,
    handleSubmit,
    handleBlur,
    values,
    touched,
    isValid,
    setFieldValue,
    errors,
  } = formik





  const option = [
    { skills: 'C', },
    { skills: 'C++', },
    { skills: 'Python', },

  ];

  return (
    <div>
      {/* <h1 style={{color:"blue"}}>Validation Form</h1> */}
      
      
      <form onSubmit={handleSubmit}>
        <Box
          component="form"
          sx={{
            '& > :not(style)': { m: 2, width: '45ch' },
          }}
          noValidate
        //   autoComplete="off"
        >


          <TextField id="name" label="Name" variant="standard" name="name"
            onChange={handleChange}
            value={values.name}
            onBlur={handleBlur} /> 
            <p> {errors.name}</p>
          <br></br>

          <TextField id="email" label="Email" variant="standard" name="email"
            onChange={handleChange}
            value={values.email}
            onBlur={handleBlur} />
             <p> {errors.email}</p>
             <br></br>

          <TextField id="num" label="Mobile number" variant="standard" name="num"
            onChange={handleChange}
            value={values.num}
            onBlur={handleBlur} /> 
            <p> {errors.num}</p>
             <br></br>

          <TextField id="pass" label="Password" variant="standard" name="pass"
           onChange={handleChange}
           value={values.pass}
           onBlur={handleBlur} /> 
           <p> {errors.pass}</p>
           <br></br>

          {/* <LocalizationProvider dateAdapter={AdapterDateFns}>

            <DatePicker
              label="Date of Birth"
              value={value1}
              onChange={(newValue) => {
                setValue1(newValue);
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  name="dob"
                  onChange={handleChange}
                  value={values.dob}
                  onBlur={handleBlur}
                  sx={{ width: 200 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              )}
            />
            <p>{errors.dob}</p>

          </LocalizationProvider> */}
          <TextField  
            label="DOB" fullWidth variant="outlined" 
            id="dob"
              type="date"
              name="dob" 
              onChange={handleChange}
             
              onBlur={handleBlur} 
            //   style={{paddingRight:"10px"}}   
              value={values.dob} 
            //   className={classes.textField}
              InputLabelProps={{
                shrink: true,
              }}
              
              />
              <p>{errors.dob}</p>

          {/* <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={option}
            getOptionLabel={(option) => option.skills}
        
            onChange={(event, newValue) => {
              console.log(newValue.lop)
              formik.setFieldValue('lop', '' + newValue.skills)
            }}

            renderInput={(params) => <TextField {...params} label="Skill" name="skills"
              onChange={handleChange}
              value={values.skills}
              onBlur={handleBlur}
              sx={{ width: 400 }} />}
          />
          <p>{errors.skills}</p> */}

          <Autocomplete
                
                autoComplete
                filterOptions={(options) => options}
                disableClearable
              
                options={option}
                getOptionLabel={(option) => option.skills}
                
                onChange={(event, newValue) => {
                  console.log(newValue.skills)
                  setFieldValue('skills', newValue.skills)
                }}
                renderInput={(params) =>
                  <TextField
                    
                    label="Skill"
                    id="Skill"
                    name="skills"
                    {...params}

                    variant="outlined"
                    // size="small"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  
                  />}
              />
              <p>{errors.skills}</p>


          </Box>


        <br></br>

        <Button id="submit" variant="contained" type="submit">
          Submit
        </Button> </form>
    </div>
  );
}

export default Validation;