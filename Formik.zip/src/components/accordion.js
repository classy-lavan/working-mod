import React from "react";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { useState } from "react";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import { Snackbar } from "@mui/material";
import Alert from "@mui/material";
const Accord = () => {

    const [value, setValue] = React.useState('');
    console.log(value);

    const handleChange = (event) => {
      setValue(event.target.value);
    };

   
    
    const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
    
  

    return (

        <div style={{ height: "100vh", margin: "5vh" }}>

            <Box sx={{ flexGrow: 1 }}>
                <AppBar position="static">
                    <Toolbar>

                        <Typography variant="h5" component="div">
                            Problem Statement
                        </Typography>

                    </Toolbar>
                </AppBar>
            </Box>
            <br></br>
            <br></br>

            <div style={{ paddingLeft: "60px" }}>
                <Button variant="text"
                    sx={{
                        ':hover': {
                            bgcolor: '#4444441c',
                            //   color: 'white',
                        },
                    }}
                    href="https://freshvoice.sgp1.digitaloceanspaces.com/techathon/TechGenzi_Techathon_Problem_Statements.pdf"
                    target="_blank"
                ><DownloadRoundedIcon />Download Problem Statements </Button>
            </div>
            <br></br>






            <div style={{ width: 1000, paddingLeft: "60px" }}>
                


                <FormControl>

                    <RadioGroup
                        aria-labelledby="demo-controlled-radio-buttons-group"
                        name="controlled-radio-buttons-group"
                    value={value}
                    onChange={handleChange}
                    >
                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <FormControlLabel value="Digital Image Face Analyzer" control={<Radio color="secondary" />} label={<Typography variant="h6">Digital Image Face Analyzer</Typography>} />
                            </AccordionSummary>
                            <AccordionDetails>
                                <div className="text">
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>
                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="Single Vendor Ecommerce App" control={<Radio color="secondary" />} label={<Typography variant="h6">Single Vendor Ecommerce App</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>
                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="Face Recognition System" control={<Radio color="secondary" />} label={<Typography variant="h6">Face Recognition System</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>
                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="LinkedIn Job Board Integration" control={<Radio color="secondary" />} label={<Typography variant="h6">LinkedIn Job Board Integration</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>

                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="Prediction of Admission & Jobs in Engineering & Technology with respect to demographic locations" control={<Radio color="secondary" />} label={<Typography variant="h6">Prediction of Admission & Jobs in Engineering & Technology with respect to demographic locations</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>

                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="Tracing IP Address behind VPN/Proxy Servers" control={<Radio color="secondary" />} label={<Typography variant="h6">Tracing IP Address behind VPN/Proxy Servers</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                        <br></br>

                        <Accordion>
                            <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                            >
                                <FormControlLabel value="AI Based Intelligent Data Extraction Engine" control={<Radio color="secondary" />} label={<Typography variant="h6">AI Based Intelligent Data Extraction Engine</Typography>} />

                            </AccordionSummary>
                            <AccordionDetails>
                                <div>
                                    <p>Build an Android mobile app or an algorithm using person’s face image meta data analysis and error level analysis to</p>
                                    <ol type="a">
                                        <li>report out image metadata including File Size, Image Width, height etc </li>
                                        <li>find the given image real or fake (authenticity of the given picture) </li>
                                        <li>Report whether given image meets image size criteria (image height and width and inside face height and width)</li>
                                        <li>Find the gender, age range, hair colour, eye colour and other features if any </li>
                                        <li>provide the list of edits if the image is photoshopped</li>
                                        <li>This app or an algorithm should accept at least JPEG image file formats and other file formats can be optional - gif, png, tiff, etc </li>
                                        <li>Restore original image if the image is photoshopped </li>
                                    </ol>
                                    <p>Fake Image</p>
                                    <p>The fake image is one that is altered using image manipulation software like Adobe Photoshop, Gimp etc.</p>
                                    <p>Error Level Analysis (ELA)</p>
                                    <p>ELA works on the basis that, an image when altered or tampered the compression ratio of the modified part will change when compared to the rest. By having a closer look at the ELA image, one can determine whether the image has been tampered with or not.</p>
                                    <p>Metadata Analysis</p>
                                    <p>Once you take a photo with your camera, a lot of information is embedded into the image (Like the name of camera, date of capture etc.) which is known as Metadata, i.e. Data about Data. Metadata is altered when tampered with any image editing software. This anomaly can be detected using metadata analyzer.</p>
                                </div>
                            </AccordionDetails>
                        </Accordion>
                    </RadioGroup>
                </FormControl>

            </div>
            <br></br>
            <div style={{ paddingLeft: "120px" }}>
                <Button variant="contained" onClick={handleClick}>Save</Button>
                <Snackbar open={open} autoHideDuration={1000}  onClose={handleClose}>
          <Alert onClose={handleClose} severity="success">
          <strong> Submitted Successfully!</strong> 
          </Alert>
            </Snackbar>
            </div>
            <br></br>

        </div>

    )

}
export default Accord;







