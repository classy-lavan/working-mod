import React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
// import './valid.css';
import { Box } from "@mui/system";
import { useFormik } from "formik";
//date picker
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
//dropdown
import Autocomplete from '@mui/material/Autocomplete';
//


function Demo() {

  const validate = (values) => {
    const errors = {};
    
    if (!values.name) {
      errors.name = "Field is required";
    }
    else if (!/^[ a-zA-Z\-\’]+$/.test(values.name)) {
      errors.name = "Invalid name";
    }


    if (!values.email) {
      errors.email = 'Field is required';
    }
    else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
      errors.email = 'Invalid email address';
    }


    if (!values.num) {
      errors.num = "Field is required";
    }
    else if (!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(values.num)) {
      errors.num = "Invalid Mobile number";
    }

    if (!values.pass) {
      errors.pass = "Field is required";
    }
    else if (!/^(?=.[a-z])(?=.[A-Z])(?=.[0-9])(?=.[!@#\$%\^&\*])(?=.{8,})/.test(values.pass)) {
      errors.pass = "Please give the strong password";
    }
    if (!values.Dateofbirth) {
      errors.Dateofbirth = "Field is required";
    }
    else if (
      !/^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/.test(values.Dateofbirth)) {
      errors.Dateofbirth = "choose valid DOB";
    }

    if (!values.skills) {
      errors.skills = "Field is required";
    }
    else if ((values.Gender = "")) {
      errors.Gender = "Field is required";
    }
    return errors;
  };
  const [value1, setValue1] = React.useState(null);
  const [value, setValue] = React.useState(null);

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      num: "",
      pass: "",
      Dateofbirth: "",
      skills: "",
    },
    validate,
    onSubmit: (values) => {
      alert(`Save Successfully!....`);
    },
  });





  const skill = [
    { label: 'C', },
    { label: 'C++', },
    { label: 'Python', },

  ];

  return (
    <div>
      <h1 style={{color:"blue"}}>Validation Form</h1>
      
      
      <form onSubmit={formik.handleSubmit}>
        <Box
          component="form"
          sx={{
            '& > :not(style)': { m: 2, width: '45ch' },
          }}
          noValidate
          autoComplete="off"
        >


          <TextField id="standard-basic" label="Name" variant="standard" name="name"
            onChange={formik.handleChange}
            value={formik.values.name}
            onBlur={formik.handleBlur} /> 
            <p> {formik.touched.name && formik.errors.name ? (
              <span class="colour">{formik.errors.name}</span>
            ) : null}</p>
          <br></br>

          <TextField id="standard-basic" label="Email" variant="standard" name="email"
            onChange={formik.handleChange}
            value={formik.values.email}
            onBlur={formik.handleBlur} /> <p> {formik.touched.email && formik.errors.email ? (
              <span class="colour">{formik.errors.email}</span>
            ) : null}</p><br></br>

          <TextField id="standard-basic" label="Mobile number" variant="standard" name="num"
            onChange={formik.handleChange}
            value={formik.values.num}
            onBlur={formik.handleBlur} /> <p> {formik.touched.num && formik.errors.num ? (
              <span class="colour">{formik.errors.num}</span>
            ) : null}</p> <br></br>

          <TextField id="standard-basic" label="Password" variant="standard" name="pass"
            onChange={formik.handleChange}
            value={formik.values.pass}
            onBlur={formik.handleBlur} /> <p> {formik.touched.pass && formik.errors.pass ? (
              <span class="colour">{formik.errors.pass}</span>
            ) : null}</p><br></br>

          <LocalizationProvider dateAdapter={AdapterDateFns}>

            <DatePicker
              label="Date of Birth"
              value={value1}
              onChange={(newValue) => {
                setValue1(newValue);
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  name="Dateofbirth"
                  onChange={formik.handleChange}
                  value={formik.values.Dateofbirth}
                  onBlur={formik.handleBlur}
                  sx={{ width: 200 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              )}
            />
            <p>{formik.touched.Dateofbirth && formik.errors.Dateofbirth ? (
              <span class="colour">{formik.errors.Dateofbirth}</span>
            ) : null}</p>

          </LocalizationProvider><br></br>

          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={skill}

            renderInput={(params) => <TextField {...params} label="Skill" name="skills"
              onChange={formik.handleChange}
              value={formik.values.skills}
              onBlur={formik.handleBlur}
              sx={{ width: 400 }} />}
          />
          <p>{formik.touched.skills && formik.errors.skills ? (
            <span class="colour">{formik.errors.skills}</span>
          ) : null}</p></Box>


        <br></br>

        <Button variant="contained" type="submit">
          Submit
        </Button> </form>
    </div>
  );
}

export default Demo;