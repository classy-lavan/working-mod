import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useState,useEffect } from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.bundle.min';

import Paper from '@mui/material/Paper';
import { Stack } from '@mui/material';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import FileOpenIcon from '@mui/icons-material/FileOpen';

import { login,getAllProb,getAllTeam } from '../service/Eval.service';


export default function Tech() {


    const [no, setNo] = useState('');

    const handleChange = (event) => {
        setNo(event.target.value);
    };
    const [no1, setNo1] = useState('');

    const handleChange1 = (event) => {
        setNo1(event.target.value);
    };
    const [no2, setNo2] = useState('');

    const handleChange2 = (event) => {
        setNo2(event.target.value);
    };
    const [no3, setNo3] = useState('');

    const handleChange3 = (event) => {
        setNo3(event.target.value);
    };
    const [no4, setNo4] = useState('');

    const handleChange4 = (event) => {
        setNo4(event.target.value);
    };



    //Login
  const loginUser = () => {
    // Make a req to login
    login("Karthikaa.Mohandass@freshvoice.in", "Techathon6*").then(res => { // handle success
      console.log(res.data.access_token);
      localStorage.setItem("access_token", res.data.access_token);
      
    invalidateProb();
    invalidateTeam();

    })
      .catch(error => {// handle error
        console.log(error);
      })
      .then(() => {// always executed
        console.log('login sucess');
      });
  }

  



const[prob,setProb]=useState([]);
console.log(prob)

  const invalidateProb = () => {
    const prob_access_token = localStorage.getItem("access_token");
    getAllProb(prob_access_token)
      .then((res) => {
        // handle success
        console.log(res);
        setProb(res.data.problem_statements);
        
      })
      .catch((error) => {
        // handle error
        console.log(error);
      })
      .then(() => {
        // always executed
        console.log("always");
      });
  };
  const[Team,setTeam]=useState([]);
  console.log(Team)
  const invalidateTeam = () => {
    const Team_access_token = localStorage.getItem("access_token");
    getAllTeam(Team_access_token)
      .then((res) => {
        // handle success
        console.log(res);
        setTeam(res.data.teams);
        
      })
      .catch((error) => {
        // handle error
        console.log(error);
      })
      .then(() => {
        // always executed
        console.log("always");
      });
  };







   // Api Integration
   useEffect(() => {

    const isDevEnv = window.location.href.includes('10086') ? true : false;
    if (isDevEnv) {
      loginUser();
    }
    else {
    //   invalidateTeam();
    //   invalidateMentor();
    invalidateProb();
    invalidateTeam()
    }
    // invalidateUsers();
    var element = document.querySelectorAll('style[data-meta="MuiButtonBase"]');
    console.log(element.length);
    if (element) {
      if (element.length > 1) {
        element[0].parentNode.removeChild(element[1]);
      }
    }
  }, []
  );





    // const drop = [
    //     { label: 'The AI Based Talent Recommender System Redemption' },
    //     { label: 'Single Vendor Ecommerce App' },
    //     { label: 'Tracing IP Address behind VPN/Proxy Servers' },
    // ]
    const down = [
        { label: 'TECH 2020' },
        { label: 'berry' },
        { label: 'cherry' },
    ]
    return (
        <div style={{ height: "100vh", margin: "5vh" }}>
            <Box display='flex' flexGrow={1} >
                <AppBar position="static" style={{ backgroundColor: " #dae5ff" }}>
                    <Toolbar>

                        <Typography variant="h4" color="#5f79ee">
                            Evaluation Section
                        </Typography>

                    </Toolbar>
                </AppBar>
            </Box>
            
            <br></br>
            <div style={{ display: "flex" }}>

                <Box
                    sx={{
                        display: 'flex',
                        '& > :not(style)': {
                            m: 1,
                            width: 800,
                            height: 650,
                        },
                    }}
                >
                    <Paper elevation={3}  >

                        <div style={{ paddingLeft: "20px", paddingTop: "10px" }} >
                            <Stack spacing={16} direction="row">
                                <div >
                                    <p>Select the Problem Statement</p>
                                </div>

                                <Autocomplete
                                    disableClearable
                                    
                                    id="combo-box-demo"
                                    // options={drop}
                                    options={prob}
                                    getOptionLabel={(option) => option.title}
                                     onChange={(e, newValue) => {
                                       console.log(newValue)
                                        setProb( newValue.title);
                                        // invalidateTeam();
                                    }}
                                    sx={{ width: 300 }}
                                    renderInput={(params) => <TextField {...params} label="Problem Statement
      " />}
                                />
                            </Stack>
                        </div>
                        <br></br>

                        <div style={{ paddingLeft: "20px" }} >
                            <Stack spacing={17.5} direction="row">
                                <div >
                                    <p>Teams solving the Problems</p>
                                </div>

                                <Autocomplete
                                // fullWidth
                                    disableClearable
                                    id="combo-box-demo"
                                    // options={down}
                                    options={Team}
                                    getOptionLabel={(option) => option.team_name}
                                     onChange={(e, newValue) => {
                                       console.log(newValue)
                                       setTeam( newValue.id);
                                    //    formik.setFieldValue( newValue.problem_statement_id);
                                    }}
                                    sx={{ width: 300 }}
                                    renderInput={(params) => <TextField {...params} label="Teams" />}
                                />
                            </Stack>
                        </div>
                        <br></br>

                        <Typography variant="h5" style={{ paddingLeft: "20px", paddingTop: "10px"}}>Evaluation Part</Typography>
                        <div style={{ padding: "20px" }}>
                            <table class="table table-bordered">
                                <thead style={{ backgroundColor: "rgb(13, 110, 253)", color: "white" }}>
                                    <tr>

                                        <th scope="col">Criteria</th>
                                        <th scope="col">Rating</th>
                                        <th scope="col">Remarks</th>
                                    </tr>
                                </thead>
                                <tbody style={{ textAlign: "center" }} >
                                    <tr>
                                        <th scope="row">Technology</th>
                                        <td >

                                            <FormControl variant="standard" sx={{ minWidth: 40 }}>

                                                <Select
                                                    labelId="demo-simple-select-standard-label"
                                                    id="Technology"
                                                    value={no}
                                                    onChange={handleChange}
                                                //   label="Age"
                                                >
                                                    {/* <MenuItem value="" color="blue"></MenuItem> */}
                                                    <MenuItem value={0}>0</MenuItem>
                                                    <MenuItem value={1}>1</MenuItem>
                                                    <MenuItem value={2}>2</MenuItem>
                                                    <MenuItem value={3}>3</MenuItem>
                                                    <MenuItem value={4}>4</MenuItem>
                                                    <MenuItem value={5}>5</MenuItem>
                                                    <MenuItem value={6}>6</MenuItem>
                                                    <MenuItem value={7}>7</MenuItem>
                                                    <MenuItem value={8}>8</MenuItem>
                                                    <MenuItem value={9}>9</MenuItem>
                                                    <MenuItem value={10}>10</MenuItem>




                                                </Select>
                                            </FormControl>




                                        </td>
                                        <td rowSpan={5}>
                                            <TextareaAutosize
                                                maxRows={4}
                                                aria-label="maximum height"


                                                style={{ width: 350 }}
                                            />


                                        </td>


                                    </tr>
                                    <tr>
                                        <th scope="row">Design</th>
                                        <td>

                                            <FormControl variant="standard" sx={{ minWidth: 40 }}>

                                                <Select
                                                    labelId="demo-simple-select-standard-label"
                                                    id="Design"
                                                    value={no1}
                                                    onChange={handleChange1}
                                                //   label="Age"
                                                >
                                                    {/* <MenuItem value="" color="blue"></MenuItem> */}
                                                    <MenuItem value={0}>0</MenuItem>
                                                    <MenuItem value={1}>1</MenuItem>
                                                    <MenuItem value={2}>2</MenuItem>
                                                    <MenuItem value={3}>3</MenuItem>
                                                    <MenuItem value={4}>4</MenuItem>
                                                    <MenuItem value={5}>5</MenuItem>
                                                    <MenuItem value={6}>6</MenuItem>
                                                    <MenuItem value={7}>7</MenuItem>
                                                    <MenuItem value={8}>8</MenuItem>
                                                    <MenuItem value={9}>9</MenuItem>
                                                    <MenuItem value={10}>10</MenuItem>




                                                </Select>
                                            </FormControl>



                                        </td>


                                    </tr>
                                    <tr>
                                        <th scope="row">Completion</th>
                                        <td>

                                            <FormControl variant="standard" sx={{ minWidth: 40 }}>

                                                <Select
                                                    labelId="demo-simple-select-standard-label"
                                                    id="Completion"
                                                    value={no2}
                                                    onChange={handleChange2}
                                                //   label="Age"
                                                >
                                                    {/* <MenuItem value="" color="blue"></MenuItem> */}
                                                    <MenuItem value={0}>0</MenuItem>
                                                    <MenuItem value={1}>1</MenuItem>
                                                    <MenuItem value={2}>2</MenuItem>
                                                    <MenuItem value={3}>3</MenuItem>
                                                    <MenuItem value={4}>4</MenuItem>
                                                    <MenuItem value={5}>5</MenuItem>
                                                    <MenuItem value={6}>6</MenuItem>
                                                    <MenuItem value={7}>7</MenuItem>
                                                    <MenuItem value={8}>8</MenuItem>
                                                    <MenuItem value={9}>9</MenuItem>
                                                    <MenuItem value={10}>10</MenuItem>




                                                </Select>
                                            </FormControl>



                                        </td>


                                    </tr>
                                    <tr>
                                        <th scope="row">Innovation</th>
                                        <td>
                                            <FormControl variant="standard" sx={{ minWidth: 40 }}>

                                                <Select
                                                    labelId="demo-simple-select-standard-label"
                                                    id="Innovation"
                                                    value={no3}
                                                    onChange={handleChange3}
                                                //   label="Age"
                                                >
                                                    {/* <MenuItem value="" color="blue"></MenuItem> */}
                                                    <MenuItem value={0}>0</MenuItem>
                                                    <MenuItem value={1}>1</MenuItem>
                                                    <MenuItem value={2}>2</MenuItem>
                                                    <MenuItem value={3}>3</MenuItem>
                                                    <MenuItem value={4}>4</MenuItem>
                                                    <MenuItem value={5}>5</MenuItem>
                                                    <MenuItem value={6}>6</MenuItem>
                                                    <MenuItem value={7}>7</MenuItem>
                                                    <MenuItem value={8}>8</MenuItem>
                                                    <MenuItem value={9}>9</MenuItem>
                                                    <MenuItem value={10}>10</MenuItem>




                                                </Select>
                                            </FormControl>



                                        </td>


                                    </tr>
                                    <tr>
                                        <th scope="row">Business Value</th>
                                        <td>

                                            <FormControl variant="standard" sx={{ minWidth: 40 }}>

                                                <Select
                                                    labelId="demo-simple-select-standard-label"
                                                    id="demo-simple-select-standard"
                                                    value={no4}
                                                    onChange={handleChange4}
                                                //   label="Age"
                                                >
                                                    {/* <MenuItem value="" color="blue"></MenuItem> */}
                                                    <MenuItem value={0}>0</MenuItem>
                                                    <MenuItem value={1}>1</MenuItem>
                                                    <MenuItem value={2}>2</MenuItem>
                                                    <MenuItem value={3}>3</MenuItem>
                                                    <MenuItem value={4}>4</MenuItem>
                                                    <MenuItem value={5}>5</MenuItem>
                                                    <MenuItem value={6}>6</MenuItem>
                                                    <MenuItem value={7}>7</MenuItem>
                                                    <MenuItem value={8}>8</MenuItem>
                                                    <MenuItem value={9}>9</MenuItem>
                                                    <MenuItem value={10}>10</MenuItem>




                                                </Select>
                                            </FormControl>



                                        </td>


                                    </tr>


                                </tbody>
                            </table>
                        </div>
                        <div style={{ marginLeft: "560px" }} >
                            <Button variant="contained"
                                sx={{
                                    ':hover': {
                                        // bgcolor: '#0d6efd',
                                        color: 'white',
                                        borderColor: "#0a58ca"

                                    },
                                }}

                            >Submit</Button>
                        </div>




                    </Paper>


                </Box>

                <Box
                    sx={{
                        // display: 'block',
                        flexWrap: "wrap",
                        '& > :not(style)': {
                            m: 1,
                            width: 610,
                            height: 200,
                        },
                    }}
                >


                    <Paper elevation={3} style={{paddingLeft: "20px",paddingTop: "10px"}} >
                        <Typography variant="h5" >
                            
                            Abstract
                        </Typography>
                        {/* <br></br> */}
                        <Stack direction={"row"} style={{paddingTop: "20px"}}>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>
                            <Button><FileOpenIcon/></Button>

                        </Stack>
                    </Paper>
                    <Box
                        sx={{
                            // display: 'flex',
                            '& > :not(style)': {
                                //   m: 1,
                                width: 610,
                                height: 200,
                            },
                        }}
                    >

                        <Paper elevation={3} style={{paddingLeft: "20px",paddingTop: "10px"}} >

                            <Typography variant="h5" >
                            Support Documents
                               
                            </Typography>
                            <div style={{paddingTop: "20px"}}>
                                <Button><FileOpenIcon/></Button>
                                </div>

                        </Paper>
                    </Box>

                    <Box
                        sx={{
                            // display: 'flex',
                            '& > :not(style)': {
                                //   m: 1,
                                width: 610,
                                height: 200,
                            },
                        }}
                    >

                        <Paper elevation={3} style={{paddingLeft: "20px",paddingTop: "10px"}}>
                            <Typography variant="h5"  >
                                Final Document
                            </Typography>
                            <div style={{paddingTop: "20px"}}>
                                <Button><FileOpenIcon/></Button>
                                </div>
                            
                        </Paper>
                    </Box>




                </Box>


            </div>
        </div>
    );
}
